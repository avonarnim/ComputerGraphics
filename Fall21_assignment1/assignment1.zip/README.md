### Graphics Assignment 1: Heigh Fields

##### Adam von Arnim

#### Features

This program begins by taking in an image as input, then processing it.
It then displays it as a set of solid triangles defined by a set of triangle meshes.
Users can select to display points or lines instead by pressing the 'p' or 'l' keys. Users can revert to solid triangles by pressing the 'g' key.
The image will be rendered as a perspective view; this can be seen especially well when looking at the spiral example image, where the spiral can be seen contracting down its length.
The user can rotate, translate, and scale the image by pressing the respective key ('r', 't', 's'), clicking on the screen, and dragging the mouse.

#### Extra Credit

I completed the extra credit option of processing color input images. This is demonstrated by my usage of a colored photo of Kermit in my video submission.
